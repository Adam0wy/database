#include <vector>
#include <queue>
#include <limits>

std::vector<std::vector<int>> fun_dijkstra(const std::vector<std::vector<double>>& transition, const std::vector<int>& from, const std::vector<int>& to) {
    // Allocate memory
    std::vector<std::vector<int>> path(from.size(), std::vector<int>(to.size()));
    std::vector<std::vector<double>> cost(from.size(), std::vector<double>(to.size()));

    // Main loop
    for (size_t i = 0; i < from.size(); i++) {
        int m = from[i];
        std::vector<bool> index(transition.size(), false);
        for (size_t j = 0; j < transition[m].size(); j++) {
            if (transition[m][j] > 0.0) {
                index[j] = true;
            }
        }
        index[m] = true;
        std::vector<double> loss(transition.size(), std::numeric_limits<double>::infinity());
        std::vector<int> parent(transition.size(), 0);
        for (size_t j = 0; j < index.size(); j++) {
            if (index[j]) {
                loss[j] = transition[m][j];
                parent[j] = m;
            }
        }
        std::queue<int> queue;
        for (size_t j = 0; j < index.size(); j++) {
            if (index[j]) {
                queue.push(j);
            }
        }

        // Explore graph
        while (!queue.empty()) {
            int k = queue.front();
            queue.pop();
            std::vector<double> distance(transition.size());
            for (size_t j = 0; j < transition[k].size(); j++) {
                distance[j] = loss[k] + transition[k][j];
            }
            std::vector<bool> new_index(transition.size(), false);
            for (size_t j = 0; j < distance.size(); j++) {
                if (distance[j] < loss[j]) {
                    loss[j] = distance[j];
                    parent[j] = k;
                    new_index[j] = true;
                }
            }
            for (size_t j = 0; j < new_index.size(); j++) {
                if (new_index[j]) {
                    queue.push(j);
                }
            }
        }

        // Back track
        for (size_t j = 0; j < to.size(); j++) {
            int n = to[j];
            path[i][j] = n;
            while (n != m && n != 0) {
                path[i][j] = parent[n];
                n = parent[n];
            }
            if (m == n) {
                path[i][j] = n;
                std::reverse(path[i][j].begin(), path[i][j].end());
            } else {
                path[i][j].clear();
            }
            cost[i][j] = loss[to[j]];
        }
    }

    return path;
}

