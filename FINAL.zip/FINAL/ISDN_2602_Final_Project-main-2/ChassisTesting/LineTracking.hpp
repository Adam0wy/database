#ifndef LineTracking_H_
#define LineTracking_H_
#include "Pinout.hpp"
#include "IRSensing.hpp"
#include <Arduino.h>

namespace LineTracking{
  void FollowingLine( uint8_t Case, uint16_t LeftSpeed, uint16_t RightSpeed );
  void RFID(bool bvar1, bool bvar2);
  void RFID2(bool bvar);
}

#endif