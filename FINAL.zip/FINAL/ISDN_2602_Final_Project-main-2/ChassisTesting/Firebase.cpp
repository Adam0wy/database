#include "Firebase.hpp"
// Initialize Firebase Data object
#include <Firebase_ESP_Client.h>
#include <addons/TokenHelper.h>
#include <addons/RTDBHelper.h>
FirebaseData fbdo;

FirebaseAuth auth;
FirebaseConfig config;

int start;
int end;
char state;
int task;

bool inter1_lt1_state;
int inter1_lt1_time;

bool inter2_lt1_state;
int inter2_lt1_time;

bool inter3_lt1_state;
int inter3_lt1_time;

bool inter4_lt1_state;
int inter4_lt1_time;

bool inter5_lt1_state;
int inter5_lt1_time;



void Fire::Init(){


unsigned long sendDataPrevMillis = 0; // Stores the last time data was sent to Firebase
unsigned long count = 0; // Counter for the number of data points sent
  // TO DO: Initialize serial communication with 115200 baud rate
  //Serial.begin(115200);

  // Connect to Wi-Fi network
  WiFi.begin(WIFI_SSID, WIFI_PASSWORD);

  Serial.print("Connecting to Wi-Fi");
  while (WiFi.status() != WL_CONNECTED)
  {
    Serial.print(".");
    delay(300); // Wait 300ms before retrying
  }
  Serial.println();
  Serial.print("Connected with IP: ");
  Serial.println(WiFi.localIP());
  Serial.println();

  Serial.printf("Firebase Client v%s\n\n", FIREBASE_CLIENT_VERSION);

  // Set up Firebase configuration
  config.api_key = API_KEY;
  auth.user.email = USER_EMAIL;
  auth.user.password = USER_PASSWORD;
  config.database_url = DATABASE_URL;
  config.token_status_callback = tokenStatusCallback; // Callback function for token status

  // Configure network reconnection behavior
  Firebase.reconnectNetwork(true);

  // Configure SSL buffer sizes for BearSSL engine
  fbdo.setBSSLBufferSize(4096 /* Rx buffer size */, 1024 /* Tx buffer size */);

  // Set the maximum size of the Firebase response payload
  fbdo.setResponseSize(2048);

  // Initialize Firebase connection
  Firebase.begin(&config, &auth);

  // Set the number of decimal places for float values in Firebase
  Firebase.setDoubleDigits(5);

  // Set server response timeout
  config.timeout.serverResponse = 10 * 1000;


}

void Fire::Sense(){

Serial.printf("start %s\n", Firebase.RTDB.getString(&fbdo, F("/demo/start_point")) ?fbdo.to<const char *>() : fbdo.errorReason().c_str());
Serial.printf("end %s\n", Firebase.RTDB.getString(&fbdo, F("/demo/end_point")) ?fbdo.to<const char *>() : fbdo.errorReason().c_str());
Serial.printf("state %s\n", Firebase.RTDB.getString(&fbdo, F("/demo/state")) ?fbdo.to<const char *>() : fbdo.errorReason().c_str());
Serial.printf("task %s\n", Firebase.RTDB.getString(&fbdo, F("/demo/task")) ?fbdo.to<const char *>() : fbdo.errorReason().c_str());

start = Firebase.RTDB.getInt(&fbdo, "/demo/start_point");
end = Firebase.RTDB.getInt(&fbdo, "/demo/end_point");
state = Firebase.RTDB.getString(&fbdo, "/demo/state");
task = Firebase.RTDB.getInt(&fbdo, "/demo/task");
}




void Fire::Traffic(){

inter1_lt1_time = Firebase.RTDB.getInt(&fbdo, "/intersections/intersection_1/traffic_lights/light_1/time_remain");
if (Firebase.RTDB.getString(&fbdo, "/intersections/intersection_1/traffic_lights/light_1/current_state")) {
  if (fbdo.stringData().equals("red")) {
    inter1_lt1_state = false;
  } 
  else {
    inter1_lt1_state = true;
  }
} 
else {
  // Handle error
  Serial.print("inter1: ");
  Serial.println(fbdo.errorReason());
}



inter2_lt1_time = Firebase.RTDB.getInt(&fbdo, "/intersections/intersection_2/traffic_lights/light_1/time_remain");
if (Firebase.RTDB.getString(&fbdo, "/intersections/intersection_2/traffic_lights/light_1/current_state")) {
  if (fbdo.stringData().equals("red")) {
    inter2_lt1_state = false;
  } 
  else {
    inter2_lt1_state = true;
  }
} 
else {
  // Handle error
  Serial.print("inter2: ");
  Serial.println(fbdo.errorReason());
}


inter3_lt1_time = Firebase.RTDB.getInt(&fbdo, "/intersections/intersection_3/traffic_lights/light_1/time_remain");
if (Firebase.RTDB.getString(&fbdo, "/intersections/intersection_3/traffic_lights/light_1/current_state")) {
  if (fbdo.stringData().equals("red")) {
    inter3_lt1_state = false;
  } 
  else {
    inter3_lt1_state = true;
  }
} else {
  // Handle error
  Serial.print("inter3: ");
  Serial.println(fbdo.errorReason());
}


inter4_lt1_time = Firebase.RTDB.getInt(&fbdo, "/intersections/intersection_4/traffic_lights/light_1/time_remain");
if (Firebase.RTDB.getString(&fbdo, "/intersections/intersection_4/traffic_lights/light_1/current_state")) {
  if (fbdo.stringData().equals("red")) {
    inter4_lt1_state = false;
  } 
  else {
    inter4_lt1_state = true;
  }
} else {
  // Handle error
  Serial.print("inter4: ");
  Serial.println(fbdo.errorReason());
}



inter5_lt1_time = Firebase.RTDB.getInt(&fbdo, "/intersections/intersection_5/traffic_lights/light_1/time_remain");
if (Firebase.RTDB.getString(&fbdo, "/intersections/intersection_5/traffic_lights/light_1/current_state")) {
  if (fbdo.stringData().equals("red")) {
    inter5_lt1_state = false;
  } 
  else {
    inter5_lt1_state = true;
  }
} else {
  // Handle error
  Serial.print("inter5: ");
  Serial.println(fbdo.errorReason());
}

// Serial.print("inter1: ");
// Serial.println(inter1_lt1_state);
// Serial.println();
// delay(10);
// Serial.print("inter2: ");
// Serial.println(inter2_lt1_state);
// Serial.println();
// delay(10);
// Serial.print("inter3: ");
// Serial.println(inter3_lt1_state);
// Serial.println();
// delay(10);
// Serial.print("inter4: ");
// Serial.println(inter4_lt1_state);
// Serial.println();
// delay(10);
// Serial.print("inter5: ");
// Serial.println(inter5_lt1_state);
// Serial.println();
// delay(10);
}