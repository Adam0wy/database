#include "LineTracking.hpp"
//decision==true then turn
//decision==false then go straight
bool decision = false;
bool cross = false;
bool rush = false;


void LineTracking::FollowingLine( uint8_t Case, uint16_t LeftSpeed, uint16_t RightSpeed ){
  switch (Case)
  {
  case OnTrack:
    //Motion::Forwards(LeftSpeed*0.8, RightSpeed*0.8);
    if (cross){
    delay(100);
    
    //cross = false;
    Serial.println("CROSSS");
    }
    else{
      if (rush == false){
    Motion::Forwards(LeftSpeed*0.8, RightSpeed*0.8);
      }
      else{
        Motion::Forwards(LeftSpeed*1.2, RightSpeed*1.2);
        vTaskDelay(1000);
        rush = false;
      }
    delay(1);
    
    };
    
  break;

  case IR_LOnTrack:
    if (decision && !cross){
    Motion::Leftwards(LeftSpeed*1.2, RightSpeed);
    vTaskDelay(10);
    }

    else if (decision && cross){
    Motion::Leftwards(LeftSpeed*0.5, RightSpeed);
    vTaskDelay(120);
    cross = false;
    }
    else{
    Motion::Forwards(LeftSpeed*0.8, RightSpeed*0.8);
    vTaskDelay(500);
    decision = true;
    };
  break;

  case IR_ROnTrack:
    //Motion::Rightwards(LeftSpeed, RightSpeed*1.2);
    // Serial.println("--------------------");
    // Serial.print("decision");
    // Serial.println(decision);
    // Serial.println("--------------------");
    if (decision && !cross){
    Motion::Rightwards(LeftSpeed, RightSpeed*1.2);
    vTaskDelay(10);
    }

    else if (decision && cross){
    Motion::Rightwards(LeftSpeed, RightSpeed*0.5);
    vTaskDelay(120);
    cross = false;
    }
    else{
    Motion::Forwards(LeftSpeed*0.8, RightSpeed*0.8);
    vTaskDelay(500);
    decision = true;
    };
  break;

  case AllOnTrack:
    Motor::Stop();
    delay(3);
  break;
  
  case OutOfTrack:
    Motion::Forwards(LeftSpeed*0.9, RightSpeed*0.9);
    delay(2);

  break;
  };


  
};
void LineTracking::RFID(bool bvar1, bool bvar2){
    decision = bvar1;
    cross = bvar2;
  };

  void LineTracking::RFID2(bool bvar){
    rush = bvar;
  };