// Wi-Fi network credentials

#ifndef Fire_H_
#define Fire_H_

#define WIFI_SSID "Xiaomi_3885" // Network SSID (name)
#define WIFI_PASSWORD "38853885" // Network password

// TO DO: Firebase configuration parameters
#define API_KEY "AIzaSyCWzx6g2Qmqdr-6lDt4pgjJJDBZBfAsFP0" // Firebase project API key
#define DATABASE_URL "https://isdn-2602-iot-default-rtdb.asia-southeast1.firebasedatabase.app/.json" // Firebase Realtime Database URL
#define USER_EMAIL "yweibq@connect.ust.hk" // Email for Firebase authentication
#define USER_PASSWORD "Weiyang34567" // Password for Firebase authentication



#include "Pinout.hpp"
#include <Arduino.h>



namespace Fire{
  void Init();
  void Sense();
  void Traffic();
};

#endif