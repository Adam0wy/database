#include "LineTracking.hpp"
//decision==true then turn
//decision==false then go straight
bool decision = false;
bool cross = false;
bool rush = false;


void LineTracking::FollowingLine( uint8_t Case, uint16_t LeftSpeed, uint16_t RightSpeed ){
  switch (Case)
  {
  case OnTrack:
    //Motion::Forwards(LeftSpeed*0.8, RightSpeed*0.8);
    if (cross){
    delay(100);
    
    //cross = false;
    Serial.println("CROSSS");
    }
    else{
      if (rush == false){
    Motion::Forwards(LeftSpeed*0.8, RightSpeed*0.8);
      }
      else{
        Motion::Forwards(LeftSpeed*3.8, RightSpeed*3.8);
        delay(3000);
        rush = false;
      }
    delay(1);
    
    };
    
  break;

  case IR_LOnTrack:
    if (decision && !cross){
    Motion::Leftwards(LeftSpeed*1.2, RightSpeed);
    delay(10);
    }

    else if (decision && cross){
    Motion::Leftwards(LeftSpeed*1.2, RightSpeed);
    delay(100);
    }
    else{
    Motion::Forwards(LeftSpeed*0.8, RightSpeed*0.8);
    delay(500);
    decision = true;
    };
  break;

  case IR_ROnTrack:
    //Motion::Rightwards(LeftSpeed, RightSpeed*1.2);
    // Serial.println("--------------------");
    // Serial.print("decision");
    // Serial.println(decision);
    // Serial.println("--------------------");
    if (decision && !cross){
    Motion::Rightwards(LeftSpeed, RightSpeed*1.2);
    delay(10);
    }

    else if (decision && cross){
    Motion::Rightwards(LeftSpeed*1.2, RightSpeed*1.2);
    delay(100);
    }
    else{
    Motion::Forwards(LeftSpeed*0.8, RightSpeed*0.8);
    delay(500);
    decision = true;
    };
  break;

  case AllOnTrack:
    Motor::Stop();
    delay(3);
  break;
  
  case OutOfTrack:
    Motion::Forwards(LeftSpeed*0.9, RightSpeed*0.9);
    delay(2);

  break;
  };


  
};
void LineTracking::RFID(bool bvar){
    decision = bvar;
    cross = bvar;
  };

  void LineTracking::RFID2(bool bvar){
    rush = bvar;
  };